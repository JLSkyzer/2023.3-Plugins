Ustawia średnią liczbę żył rudy, która ma się wygenerować na chunk.

Standardowe wartości liczby żył rudy na chunk:

* Ruda Węgla - 20
* Ruda Żelaza - 20
* Ruda Złota - 2
* Ruda Redstone - 8
* Ruda Diamentu - 1
* Ruda Lazurytu - 1