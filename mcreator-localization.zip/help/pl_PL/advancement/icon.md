Ikona pokazuje się w zakładce postępów.

Jeżeli jest to pierwsze osiągnięcie, będzie to również ikona danej ścieżki postępów.

Tylko przedmioty są tutaj obsługiwane. Bloki nieposiadające przedmiotu nie mogą być ukazane jako ikona.