To jest osiągnięcie, po którym następuje twoje osiągnięcie.

Możesz użyć "Brak rodzica: korzeń", żeby utworzyć nową ścieżkę (nową zakładkę postępów).