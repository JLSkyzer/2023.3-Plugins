This determines how big or small the entity's model will appear. 
This does not change the entity's bounding box size, even if it looks like it changed, only its size.