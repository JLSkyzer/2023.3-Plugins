Ce sera le nom utilisé lors de la recherche d'un groupe de modèles à désactiver et à remplacer par un bras de joueur.
Ce bras aura alors les animations du groupe de modèles.
Si le groupe de modèles spécifié n'existe pas, le bras ne sera pas rendu.