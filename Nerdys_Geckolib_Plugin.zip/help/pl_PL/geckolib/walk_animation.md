To jest animacja będzie odtwarzana gdy istota idzie i żadna inna animacja nie jest aktywna.
Jeśli byt ma animację latania, będzie ona odtwarzana tylko wtedy gdy istota chodzi po ziemi.