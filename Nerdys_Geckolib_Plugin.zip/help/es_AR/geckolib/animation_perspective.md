Este parámetro determina en qué perspectivas se reproducirán las animaciones de los elementos.
"Todas las perspectivas" siempre permitirá que se reproduzcan las animaciones,
"Primera Persona" sólo reproducirá animaciones cuando esté en primera persona y
"Tercera/Segunda Persona" sólo reproducirá animaciones cuando no esté en primera persona.